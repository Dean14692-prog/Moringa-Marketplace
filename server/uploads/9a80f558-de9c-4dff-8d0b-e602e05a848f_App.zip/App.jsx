// // import { useState } from "react";
// // import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// // import "./App.css";

// // import About from "./components/about";
// // import CategoriesPage from "./components/category";
// // import Contact from "./components/contact";
// // import LandingPage from "./components/landingpage";
// // // import Navbar from "./components/navbar";
// // import SourcePage from "./components/sourcepage";
// // import SignupForm from "./components/signup";
// // import Footer from "./components/footer";

// // function App() {
// //   const [isDark, setIsDark] = useState(false);

// //   const toggleTheme = () => setIsDark((prev) => !prev);

// //   return (
// //     <Router>
// //       <div className={isDark ? "bg-black text-white" : "bg-white text-black"}>
// //         {/* <Navbar isDark={isDark} toggleTheme={toggleTheme} /> */}
// //         <Routes>
// //           <Route path="/" element={<LandingPage />} />
// //           <Route path="/about" element={<About />} />
// //           <Route path="/category" element={<CategoriesPage />} />
// //           <Route path="/contact" element={<Contact />} />
// //           {/* <Route path="/privacy-policy" element={<PrivacyPolicy />} />  */}
// //           <Route path="/sourcepage" element={<SourcePage />} />
// //           <Route path="/signup" element={<SignupForm />} />
// //         </Routes>
// //       </div>
// //       <Footer />
// //     </Router>
// //   );
// // }

// // export default App;
// // src/App.jsx
// import { useState } from "react";
// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import "./App.css";

// import About from "./components/about";
// import CategoriesPage from "./components/category";
// import Contact from "./components/contact";
// import LandingPage from "./components/landingpage"; // This is your actual homepage
// import SourcePage from "./components/sourcepage";
// import Signup from "./components/Signup";
// import Login from "./components/Login";
// import Footer from "./components/footer";

// function App() {
//   const [isDark, setIsDark] = useState(false);

//   const toggleTheme = () => setIsDark((prev) => !prev);

//   return (
//     <Router>
//       <div className={isDark ? "bg-black text-white" : "bg-white text-black"}>
//         <Routes>
//           <Route path="/" element={<LandingPage />} />      {/* Homepage after login */}
//           <Route path="/about" element={<About />} />
//           <Route path="/category" element={<CategoriesPage />} />
//           <Route path="/contact" element={<Contact />} />
//           <Route path="/sourcepage" element={<SourcePage />} />
//           <Route path="/signup" element={<Signup />} />
//           <Route path="/login" element={<Login />} />
//         </Routes>
//         <Footer />
//       </div>
//     </Router>
//   );
// }

// export default App;

// src/App.jsx
import { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";

import About from "./components/about";
import CategoriesPage from "./components/category";
import Contact from "./components/contact";
import LandingPage from "./components/landingpage";
import SourcePage from "./components/sourcepage";
import Signup from "./components/Signup";
import Login from "./components/Login";
import Footer from "./components/footer";
// import Navbar from "./components/navbar"; // Uncomment if you have it

function App() {
  const [isDark, setIsDark] = useState(false);

  const toggleTheme = () => setIsDark((prev) => !prev);

  return (
    <Router>
      <div className={isDark ? "bg-black text-white" : "bg-white text-black"}>
        {/* <Navbar isDark={isDark} toggleTheme={toggleTheme} /> */}
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/about" element={<About />} />
          <Route path="/category" element={<CategoriesPage />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/sourcepage" element={<SourcePage />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </div>
      <Footer />
    </Router>
  );
}

export default App;
