import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-[#0D1B2A] text-white px-4 sm:px-6 lg:px-8 py-10 md:py-12">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8 md:gap-12">
        {/* Column 1: Logo + Contact Info */}
        <div className="md:col-span-1 lg:col-span-2"> {/* Allow logo column to take more space on larger screens */}
          <h2 className="text-3xl font-extrabold mb-4 tracking-wide">MORINGA</h2> {/* Slightly larger, bolder, spaced out */}
          <p className="text-sm mb-1 text-gray-300">Ngong Lane Plaza, 1st Floor</p>
          <p className="text-sm mb-1 text-gray-300">Nairobi, Kenya</p>
          
          <div className="mt-6 space-y-2"> {/* Group contact numbers for better spacing */}
            <p className="text-sm flex items-center text-gray-300">
              <span className="mr-2 text-yellow-400">📞</span> +254711 222 999
            </p>
            <p className="text-sm flex items-center text-gray-300">
              <span className="mr-2 text-yellow-400">📞</span> +254711 222 999 (WhatsApp)
            </p>
          </div>
          
          <div className="mt-4 space-y-2"> {/* Group emails for better spacing */}
            <p className="text-sm flex items-center text-gray-300">
              <span className="mr-2 text-yellow-400">📧</span> g1@moringaschool.com
            </p>
            <p className="text-sm flex items-center text-gray-300">
              <span className="mr-2 text-yellow-400">📧</span> g1@moringaschool.com
            </p>
          </div>
        </div>

        {/* Column 2: Quick Links */}
        <div className="md:col-span-1">
          <h3 className="text-xl font-semibold mb-5 text-yellow-400">Quick Links</h3> {/* Highlighted title */}
          <ul className="space-y-3 text-sm"> {/* Slightly more vertical space */}
            <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Projects</a></li>
            <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Careers</a></li>
            <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">FAQs</a></li>
            <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Contacts Us</a></li>
            <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Privacy Policy</a></li>
          </ul>
        </div>

        {/* Column 3: Google Map */}
        <div className="md:col-span-1">
          <h3 className="text-xl font-semibold mb-5 text-yellow-400">Find Us</h3> {/* Highlighted title */}
          <iframe
            title="Moringa Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.790933742468!2d36.78771457497177!3d-1.297495535623098!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f10b75a109a93%3A0xc3f8b0e87b7a7c81!2sMoringa%20School!5e0!3m2!1sen!2ske!4v1700000000000!5m2!1sen!2ske" // **IMPORTANT: Use a real Google Maps Embed URL**
            width="100%"
            height="220" // Slightly increased height for better visibility
            className="rounded-lg shadow-md border-none" // Rounded corners and subtle shadow
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="mt-12 border-t border-gray-700 pt-6 text-center text-sm text-gray-500"> {/* More top margin, slightly lighter text */}
        © {new Date().getFullYear()} Moringa School. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;